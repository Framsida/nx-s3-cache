export const handler = async () => ({ statusCode: 404, body: "" });
